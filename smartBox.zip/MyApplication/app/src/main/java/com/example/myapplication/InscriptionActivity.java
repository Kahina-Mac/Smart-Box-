package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;

public class InscriptionActivity extends AppCompatActivity {
    EditText etName,etPass,etConfirmPass;
    Button btSubmit;
    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        etName = findViewById(R.id.et_name);
        //etEmail = findViewById(R.id.et_email);
        etPass = findViewById(R.id.et_pass);
        etConfirmPass = findViewById(R.id.et_confirm_pass);
        btSubmit = findViewById(R.id.bt_submit);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this, R.id.et_name,
                RegexTemplate.NOT_EMPTY, R.string.invalid_name);

        //awesomeValidation.addValidation(this, R.id.et_email,
               // Patterns.EMAIL_ADDRESS, R.string.invalid_email);

        awesomeValidation.addValidation(this, R.id.et_pass,
                ".{5,}",R.string.invalid_pass);

        awesomeValidation.addValidation(this, R.id.et_confirm_pass,
                R.id.et_password, R.string.invalid_confirm_pass);

        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (awesomeValidation.validate()){
                    Toast.makeText(getApplicationContext(), "Form Validate Succefully", Toast.LENGTH_SHORT).show();
                    Intent inte = new Intent(InscriptionActivity.this, MainActivity.class);
                    startActivity(inte);
                } else {
                    Toast.makeText(getApplicationContext(), "Validation Faild", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
