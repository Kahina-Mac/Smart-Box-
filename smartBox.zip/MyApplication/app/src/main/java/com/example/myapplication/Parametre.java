package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Parametre extends AppCompatActivity {
    Button btdelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        btdelete= findViewById(R.id.bt_delete);
        btdelete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent ii = new Intent(Parametre.this, InscriptionActivity.class);
                startActivity(ii);
                AlertDialog.Builder builder =  new AlertDialog.Builder(Parametre.this);
                builder.setIcon(R.drawable.ic_check);
                builder.setTitle("Delete Successfully");
                builder.setMessage("Please create account to log");
                builder.setNegativeButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }
}
