package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class CompteActivity extends AppCompatActivity {
    Button btNotification, btLocalisation;

    DrawerLayout dl;
    ActionBarDrawerToggle abdt;


    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compte);

        btNotification = findViewById(R.id.bt_notification);
        btLocalisation = findViewById(R.id.bt_localisation);
        btNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "Etat du colis : latitude: 28.545799 et longitude: 77.170303 , Humidité : 53, Température 46";
                NotificationCompat.Builder builder = new NotificationCompat.Builder(
                        CompteActivity.this
                )
                        .setSmallIcon(R.drawable.ic_message)
                        .setContentTitle("New Notification")
                        .setContentText(message)
                        .setAutoCancel(true);
                Intent intent =  new Intent(CompteActivity.this,
                        NotificationsActivity.class);
                startActivity(intent);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("message",message);
                PendingIntent pendingIntent = PendingIntent.getActivity(CompteActivity.this,
                        0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);
                NotificationManager notificationManager = (NotificationManager)getSystemService(
                        Context.NOTIFICATION_SERVICE
                );
                notificationManager.notify(0,builder.build());
            }

        });
        btLocalisation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inten =  new Intent(CompteActivity.this,
                        MapsActivity.class);
                startActivity(inten);
            }
        });


        dl = findViewById(R.id.dl);
        abdt = new ActionBarDrawerToggle(this,dl,R.string.open,R.string.close);
        abdt.setDrawerIndicatorEnabled(true);

        dl.addDrawerListener(abdt);
        abdt.syncState();
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

    final  NavigationView nav_view = findViewById(R.id.nav_view);

        //Ajouter cette ligne
        nav_view.bringToFront();

        nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
               int id = item.getItemId();
               boolean retour = true;

                switch (item.getItemId()){
                    case R.id.myrofile :
                        Toast.makeText(getApplicationContext(), "Le menu profil est sélectionné", Toast.LENGTH_LONG).show();
                        Intent intent1 =  new Intent(CompteActivity.this,
                                Profil.class);
                        startActivity(intent1);

                        break;
                    case R.id.settings :
                        Toast.makeText(getApplicationContext(), "Le menu Setting est sélectionné", Toast.LENGTH_LONG).show();
                        Intent intent2 =  new Intent(CompteActivity.this,
                                Parametre.class);
                        startActivity(intent2);
                        break;
                    case R.id.deconnexion :
                        Toast.makeText(getApplicationContext(), "Le menu Deconnexion est sélectionné", Toast.LENGTH_LONG).show();
                        Intent itent3 = new Intent(CompteActivity.this, MainActivity.class);
                        startActivity(itent3);
                        break;

                }

                dl.closeDrawers();

                return false;
                //return retour;
            }
        });
    }



   /* @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.myrofile){
            Intent intent = new Intent(CompteActivity.this, MyProfileActivity.class);
            startActivity(intent);
            return false;
        }
        if (id==R.id.settings) {
            Intent intent = new Intent(CompteActivity.this, SettingsActivity.class);
            startActivity(intent);
            return false;
        }
        if (id==R.id.deconnexion){
            Intent intent = new Intent(CompteActivity.this, MainActivity.class);
            startActivity(intent);
            return false;
        }
        return abdt.onOptionsItemSelected(item)
        || super.onOptionsItemSelected(item);
    }*/
}
